
from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample in-memory candidate data
candidates = [
    {
        "id": 1,
        "name": "Alice",
        "skills": ["Python", "Flask", "SQL"],
        "experience": 3
    },
    {
        "id": 2,
        "name": "Bob",
        "skills": ["JavaScript", "Node.js", "MongoDB"],
        "experience": 2
    },
    {
        "id": 3,
        "name": "Charlie",
        "skills": ["Python", "Django", "REST"],
        "experience": 5
    }
]

@app.route("/candidates", methods=["GET"])
def get_candidates():
    return jsonify(candidates)

@app.route("/shortlist", methods=["POST"])
def shortlist_candidates():
    data = request.json
    required_skills = data.get("skills", [])
    min_experience = data.get("min_experience", 0)

    shortlisted = []
    for c in candidates:
        if all(skill in c["skills"] for skill in required_skills) and c["experience"] >= min_experience:
            shortlisted.append(c)

    return jsonify({
        "count": len(shortlisted),
        "shortlisted_candidates": shortlisted
    })

if __name__ == "__main__":
    app.run(debug=True)

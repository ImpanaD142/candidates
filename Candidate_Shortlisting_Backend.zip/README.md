
# Candidate Shortlisting Backend

## Description
A simple Flask-based backend utility to shortlist candidates based on skills and experience.

## Setup Instructions
1. Install dependencies:
   pip install -r requirements.txt

2. Run the server:
   python app.py

Server runs on http://127.0.0.1:5000

## API Documentation

### GET /candidates
Returns all candidates.

### POST /shortlist
Shortlist candidates based on criteria.

#### Request Body (JSON)
{
  "skills": ["Python"],
  "min_experience": 3
}

#### Response
{
  "count": 1,
  "shortlisted_candidates": [
    {
      "id": 1,
      "name": "Alice",
      "skills": ["Python", "Flask", "SQL"],
      "experience": 3
    }
  ]
}
